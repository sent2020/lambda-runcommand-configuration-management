"""
This AWS Lambda function is intended to be invoked via a Cloudwatch Event for a
new intance launch. We get the instance ID from the event message, find our pipeline
bucket, the latest artifact in the bucket, tell the new instance to grab the
artifact, and finally execute it locally via runcommand.
chavisb@amazon.com
v0.0.1
"""
import datetime
import logging
import boto3
from botocore.exceptions import ClientError

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

# assume we're always using a pipeline name GARLC
PIPELINE_NAME = 'GARLC'

def is_a_garlc_instance(instance_id):
    """
    Determine if an instance is GARLC enabled
    """
    filters = [
        {'Name': 'tag:has_ssm_agent', 'Values': ['true', 'True']}
    ]
    try:
        ec2 = boto3.resource('ec2')
        instance = ec2.describe_instances(InstanceIds=[str(instance_id)])
    except ClientError as err:
        LOGGER.error(str(err))
        return False

    if instance.filter(Filters=filters):
        return True
    else:
        LOGGER.error(str(instance_id) + " is not a GARLC instance!")
        return False

def find_bucket():
    """
    find S3 bucket that codedeploy uses and return bucket name
    """
    try:
        codepipeline = boto3.client('codepipeline')
        pipeline = codepipeline.get_pipeline(name=PIPELINE_NAME)
        return pipeline['pipeline']['artifactStore']['location']
    except (IOError, ClientError, KeyError) as err:
        LOGGER.error(err)
        return False

def find_newest_artifact(bucket):
    """
    find and return the newest artifact in codepipeline bucket
    """
    #TODO
    #implement boto collections to support more than 1000 artifacts per bucket
    try:
        aws_s3 = boto3.client('s3')
        objects = aws_s3.list_objects(Bucket=bucket)
        artifact_list = [i['LastModified'] for i in objects['Contents']]
        return sorted(artifact_list[-1])
    except (IOError, ClientError, KeyError) as err:
        LOGGER.error(err)
        return False

def ssm_commands(artifact):
    """
    Builds commands to be sent to SSM (Run Command)
    """
    # TODO
    # Error handling in the command generation
    utc_datetime = datetime.datetime.utcnow()
    timestamp = utc_datetime.strftime("%Y%m%d%H%M%S")
    return [
        'aws configure set s3.signature_version s3v4',
        'aws s3 cp {0} /tmp/{1}.zip --quiet'.format(artifact, timestamp),
        'unzip -qq /tmp/{0}.zip -d /tmp/{1}'.format(timestamp, timestamp),
        'bash /tmp/{0}/generate_inventory_file.sh'.format(timestamp),
        'ansible-playbook -i "/tmp/inventory" /tmp/{0}/ansible/playbook.yml'.format(timestamp)
    ]

def send_run_command(instance_id, commands):
    """
    Sends the Run Command API Call
    """
    try:
        ssm = boto3.client('ssm')
        ssm.send_command(
            InstanceId=instance_id,
            DocumentName='AWS-RunShellScript',
            TimeoutSeconds=300,
            Parameters={
                'commands': commands,
                'executionTimeout': ['120']
            }
        )
        return 'success'
    except ClientError as err:
        return err

def log_event(event):
    """Logs event information for debugging"""
    LOGGER.info("====================================================")
    LOGGER.info(event)
    LOGGER.info("====================================================")

def get_instance_id(event):
    """ Grab the instance ID out of the "event" dict sent by cloudwatch events """
    try:
        return event['detail']['EC2InstanceId']
    except KeyError as err:
        LOGGER.error(err)
        return False

def resources_exist(instance_id, bucket):
    """
    Validates instance_id and bucket have values
    """
    if instance_id is False:
        LOGGER.error('Unable to retrieve Instance ID!')
        return False
    elif bucket is False:
        LOGGER.error('Unable to retrieve Bucket Name!')
        return False
    else: return True


def handle(event, _context):
    """ Lambda Handler """
    log_event(event)
    instance_id = get_instance_id(event)
    bucket = find_bucket()

    if resources_exist(instance_id, bucket) and is_a_garlc_instance(instance_id):
        artifact = find_newest_artifact(bucket)
        commands = ssm_commands(artifact)
        send_run_command(instance_id, commands)
        return True
    else:
        return False
